#ifndef _OF_APP
#define _OF_APP

#include "ofMain.h"
#include "ofxMaxim.h"
#include "ofxGui.h"
#include "ofxOsc.h"
#include "ofxMidi.h"

#include "maxiMFCC.h"
#define HOST "localhost"
#define PORT 12000

class ofApp : public ofBaseApp{
    
public:
    ~ofApp();/* deconsructor is very useful */
    void setup();
    void update();
    void draw();
	void exit();

    void keyPressed  (int key);
    void keyReleased(int key);
    void mouseMoved(int x, int y );
    void mouseDragged(int x, int y, int button);
    void mousePressed(int x, int y, int button);
    void mouseReleased(int x, int y, int button);
    void windowResized(int w, int h);        
    
	// ------| audio + maximilian stuff |
	void audioRequested(float * input, int bufferSize, int nChannels);
	void audioReceived(float * input, int bufferSize, int nChannels);

	float 	* lAudioOut;
	float   * rAudioOut;
	float * lAudioIn;
	float * rAudioIn;
	int		initialBufferSize;
	int		sampleRate;

	double wave, sample, outputs[2], ifftVal;
	maxiMix mymix;
	maxiOsc osc;

	ofxMaxiFFTOctaveAnalyzer oct;
	int nAverages;
	float *ifftOutput;
	int ifftSize;
	float peakFreq = 0;
	float centroid = 0;
	float RMS = 0;
	ofxMaxiIFFT ifft;
	ofxMaxiFFT mfft;
	int fftSize;
	int bins, dataSize;
	maxiMFCC mfcc;
	double *mfccs;
	maxiSample samp;

	// ------| data buffer stuff |
	vector< vector<float> > dataBuff;
	vector<float> d0;
	vector<float> mB;
	int dBuffSize;
	int nBands;
	int rot;

	// ------| gui |
    bool bHide;
    
    ofxToggle mfccToggle;
    ofxToggle fftToggle;
    ofxToggle chromagramToggle;
    ofxToggle peakFrequencyToggle;
    ofxToggle centroidToggle;
	ofxToggle rmsToggle;
       
    ofxPanel gui;
    ofTrueTypeFont myfont, myFont2, myFont5;
    
	ofxToggle en_dsp;
	ofxToggle on_g1, on_g2, on_g3, on_g4;
	ofxIntSlider pan_g1, pan_g2, pan_g3, pan_g4;
	ofxIntSlider tilt_g1, tilt_g2, tilt_g3, tilt_g4;

	ofxToggle dsp_g1, dsp_g2, dsp_g3, dsp_g4;
	ofxIntSlider cq_g1, cq_g2, cq_g3, cq_g4;
	ofxIntSlider thr_g1, thr_g2, thr_g3, thr_g4;
	ofxIntSlider top_g1, top_g2, top_g3, top_g4;

	// ------| osc |
    ofxOscSender sender;

	// ------| regular stuff |
	ofFbo canvas;
	ofPoint p_a;
	int w, h, bw, bh, t;
	float tt;

	// ------| midi stuff |
	ofxMidiOut midiOut;
	int midiCh;

	unsigned int currentPgm;
	int note, velocity;
	int pan, bend, touch, polytouch;
    
	int mode_g1, mode_g2, mode_g3, mode_g4;
	int st_pan_g1, st_pan_g2, st_pan_g3, st_pan_g4;
	int st_tilt_g1, st_tilt_g2, st_tilt_g3, st_tilt_g4;

	int a1, a2, a3, a4;

	int aux;
};

#endif
