/* Audio input to Midi-DMX.
 */


#include "ofApp.h"
#include "maximilian.h"/* include the lib */
#include "time.h"


// 1, 25, 49, 73, 97, 121, 145
// o - 25, 49, 0 , 73, 97 - o

#define CH_DMX_G1_PAN	1
#define CH_DMX_G1_TILT	2		
#define CH_DMX_G1_DIM	24


//#define CH_DMX_G1_PAN	25
//#define CH_DMX_G1_TILT	27
//#define CH_DMX_G1_DIM	47

#define CH_DMX_G2_PAN	49
#define CH_DMX_G2_TILT	51
#define CH_DMX_G2_DIM	71

#define CH_DMX_G3_PAN	73
#define CH_DMX_G3_TILT	75
#define CH_DMX_G3_DIM	95

#define CH_DMX_G4_PAN	97
#define CH_DMX_G4_TILT	99
#define CH_DMX_G4_DIM	119


//-------------------------------------------------------------
ofApp::~ofApp() {
    
}


//--------------------------------------------------------------
void ofApp::setup(){
    
	/* data coms */
    sender.setup(HOST, PORT);
	midiOut.listOutPorts();
	midiOut.openPort(1); // by number 
	midiCh = 1;
	note = 0;
	velocity = 0;

	/* some standard setup stuff*/
    ofEnableAlphaBlending();
    ofSetupScreen();
	ofSetVerticalSync(true);
	ofSetCircleResolution(60);

	ofSetFrameRate(60);
	ofBackground(0);
	w = ofGetWidth();
	h = ofGetHeight();

	// ------ ------ ------ ------ ------ ------ | dsp |
	sampleRate = 44100;
	initialBufferSize = 512;
	lAudioOut = new float[initialBufferSize];
	rAudioOut = new float[initialBufferSize];
	lAudioIn = new float[initialBufferSize];
	rAudioIn = new float[initialBufferSize];
	memset(lAudioOut, 0, initialBufferSize * sizeof(float));
	memset(rAudioOut, 0, initialBufferSize * sizeof(float));
	memset(lAudioIn, 0, initialBufferSize * sizeof(float));
	memset(rAudioIn, 0, initialBufferSize * sizeof(float));

	fftSize = 1024;
	mfft.setup(fftSize, 512, 256);
	ifft.setup(fftSize, 512, 256);
	nAverages = 12;
	oct.setup(sampleRate, fftSize / 2, nAverages);
	mfccs = (double*)malloc(sizeof(double) * 13);
	mfcc.setup(512, 42, 13, 20, 20000, sampleRate);
	ofxMaxiSettings::setup(sampleRate, 2, initialBufferSize);
	ofSoundStreamSetup(2, 2, this, sampleRate, initialBufferSize, 4); // Call this last ! 
																	  // fft :: 512 , mfft.magnitudes[i] , pitch/timbral/vol
																	  // MFCC :: 13 , mfccs[i] , timbre/vocal
																	  // CosQ :: 104, oct.averages[i] , 12 bands/oct
																	  // peak :: peakFreq, spectral centroid :: centroid, rms::RMS
	nBands = 104;
	dBuffSize = 8;
	d0.resize(nBands);
	mB.resize(nBands);
	dataBuff.resize(dBuffSize);
	for (int n = 0; n < dBuffSize; n++) { dataBuff[n].resize(nBands); }

    
    //GUI STUFF
    gui.setup(); // most of the time you don't need a name
	gui.add(on_g1.setup("G1", false));
	gui.add(pan_g1.setup("pan_1", 64, 0, 127));
	gui.add(tilt_g1.setup("tilt_1", 64, 0, 127));
	gui.add(dsp_g1.setup("dsp_1", false));
	gui.add(cq_g1.setup("cq_1", 12, 0, 96));
	gui.add(thr_g1.setup("lo_1", 5, 1, 12));
	gui.add(top_g1.setup("hi_1", 10, 1, 12));

	gui.add(on_g2.setup("G2", false));
	gui.add(pan_g2.setup("pan_2", 64, 0, 127));
	gui.add(tilt_g2.setup("tilt_2", 64, 0, 127));
	gui.add(dsp_g2.setup("dsp_2", false));
	gui.add(cq_g2.setup("cq_2", 24, 0, 96));
	gui.add(thr_g2.setup("lo_2", 5, 1, 12));
	gui.add(top_g2.setup("hi_2", 10, 1, 12));

	gui.add(on_g3.setup("G3", false));
	gui.add(pan_g3.setup("pan_3", 64, 0, 127));
	gui.add(tilt_g3.setup("tilt_3", 64, 0, 127));
	gui.add(dsp_g3.setup("dsp_3", false));
	gui.add(cq_g3.setup("cq_3", 48, 0, 96));
	gui.add(thr_g3.setup("lo_3", 5, 1, 12));
	gui.add(top_g3.setup("hi_3", 10, 1, 12));

	gui.add(on_g4.setup("G4", false));
	gui.add(pan_g4.setup("pan_4", 64, 0, 127));
	gui.add(tilt_g4.setup("tilt_4", 64, 0, 127));
	gui.add(dsp_g4.setup("dsp_4", false));
	gui.add(cq_g4.setup("cq_4", 72, 0, 96));
	gui.add(thr_g4.setup("lo_4", 5, 1, 12));
	gui.add(top_g4.setup("hi_4", 10, 1, 12));

    myfont.loadFont("vcr_mono.ttf", 18); //requires this to be in bin/data/
    myFont2.loadFont("vcr_mono.ttf", 12); //requires this to be in bin/data/
	myFont5.loadFont("vcr_mono.ttf", 7); //requires this to be in bin/data/
	canvas.allocate(300, 500, GL_RGBA);
	bHide = true;

	mode_g1 = 0;	
	mode_g2 = 0;	
	mode_g3 = 0;	
	mode_g4 = 0;
	st_pan_g1 = 64;
	st_pan_g2 = 64;
	st_pan_g3 = 64;
	st_pan_g4 = 64;
	st_tilt_g1 = 64;
	st_tilt_g2 = 64;
	st_tilt_g3 = 64;
	st_tilt_g4 = 64;

	midiOut.sendNoteOn(midiCh, 16, 64);
	// midiOut.sendNoteOn(midiCh, 15, 127);

	for (int i = 1; i < 16; i++) {
		midiOut.sendNoteOn(midiCh, i, 0);
	}
}

//--------------------------------------------------------------
void ofApp::update(){
	t = ofGetElapsedTimeMillis();
	tt = ofGetElapsedTimef();
	std::stringstream strm;
	strm << "[I N T E R S P E C I F I C S] :: AAA-nyan-lyse-RRR :: " << ofGetFrameRate() << " fps";
	ofSetWindowTitle(strm.str());

	// ------ | dsp |
	for (int b = 0; b < nBands; b++) { if (oct.averages[b] > 0) { d0[b] = oct.averages[b]; } }
	for (int n = dBuffSize - 1; n > 0; n--) { dataBuff[n] = dataBuff[n - 1]; }
	dataBuff[0] = d0;
	for (int b = 0; b < nBands; b++) {
		mB[b] = 0;
		for (int n = 0; n < dBuffSize; n++) { mB[b] += dataBuff[n][b]; }
		mB[b] /= dBuffSize;
	}
	
	// --- on/off mode
	if (mode_g1 == 0 && on_g1 == true) {
		mode_g1 = 1;
		midiOut.sendNoteOn(midiCh, CH_DMX_G1_DIM, 64);
	}
	else if (mode_g1 == 1 && on_g1 == false) {
		mode_g1 = 0;
		midiOut.sendNoteOn(midiCh, CH_DMX_G1_DIM, 0);
	}
	if (mode_g2 == 0 && on_g2 == true) {
		mode_g2 = 1;
		midiOut.sendNoteOn(midiCh, CH_DMX_G2_DIM, 64);
	}
	else if (mode_g2 == 1 && on_g2 == false) {
		mode_g2 = 0;
		midiOut.sendNoteOn(midiCh, CH_DMX_G2_DIM, 0);
	}
	if (mode_g3 == 0 && on_g3 == true) {
		mode_g3 = 1;
		midiOut.sendNoteOn(midiCh, CH_DMX_G3_DIM, 64);
	}
	else if (mode_g3 == 1 && on_g3 == false) {
		mode_g3 = 0;
		midiOut.sendNoteOn(midiCh, CH_DMX_G3_DIM, 0);
	}
	if (mode_g4 == 0 && on_g4 == true) {
		mode_g4 = 1;
		midiOut.sendNoteOn(midiCh, CH_DMX_G4_DIM, 127);
	}
	else if (mode_g4 == 1 && on_g4 == false) {
		mode_g4 = 0;
		midiOut.sendNoteOn(midiCh, CH_DMX_G4_DIM, 0);
	}

	// --- -- | pan |
	if (st_pan_g1 != pan_g1) { 
		st_pan_g1 = pan_g1;
		midiOut.sendNoteOn(midiCh, CH_DMX_G1_PAN, st_pan_g1);
	}
	if (st_pan_g2 != pan_g2) {
		st_pan_g2 = pan_g2;
		midiOut.sendNoteOn(midiCh, CH_DMX_G2_PAN, st_pan_g2);
	}
	if (st_pan_g3 != pan_g3) {
		st_pan_g3 = pan_g3;
		midiOut.sendNoteOn(midiCh, CH_DMX_G3_PAN, st_pan_g3);
	}
	if (st_pan_g4 != pan_g4) {
		st_pan_g4 = pan_g4;
		midiOut.sendNoteOn(midiCh, CH_DMX_G4_PAN, st_pan_g4);
	}

	// --- -- | tilt |
	if (st_tilt_g1 != tilt_g1) {
		st_tilt_g1 = tilt_g1;
		midiOut.sendNoteOn(midiCh, CH_DMX_G1_TILT, st_tilt_g1);
	}
	if (st_tilt_g2 != tilt_g2) {
		st_tilt_g2 = tilt_g2;
		midiOut.sendNoteOn(midiCh, CH_DMX_G2_TILT, st_tilt_g2);
	}
	if (st_tilt_g3 != tilt_g3) {
		st_tilt_g3 = tilt_g3;
		midiOut.sendNoteOn(midiCh, CH_DMX_G3_TILT, st_tilt_g3);
	}
	if (st_tilt_g4 != tilt_g4) {
		st_tilt_g4 = tilt_g4;
		midiOut.sendNoteOn(midiCh, CH_DMX_G4_TILT, st_tilt_g4);
	}

	// dsp on/off
	if (mode_g1 == 0 && dsp_g1 == true) {
		mode_g1 = 5;
	}
	else if (mode_g1 == 5 && dsp_g1 == false) {
		mode_g1 = 0;
		a1 = 0;
		midiOut.sendNoteOn(midiCh, CH_DMX_G1_DIM, 0);
	}
	if (mode_g2 == 0 && dsp_g2 == true) {
		mode_g2 = 5;
	}
	else if (mode_g2 == 5 && dsp_g2 == false) {
		mode_g2 = 0;
		a2 = 0;
		midiOut.sendNoteOn(midiCh, CH_DMX_G2_DIM, 0);
	}
	if (mode_g3 == 0 && dsp_g3 == true) {
		mode_g3 = 5;
	}
	else if (mode_g3 == 5 && dsp_g3 == false) {
		mode_g3 = 0;
		a3 = 0;
		midiOut.sendNoteOn(midiCh, CH_DMX_G3_DIM, 0);
	}
	if (mode_g4 == 0 && dsp_g4 == true) {
		mode_g4 = 5;
	}
	else if (mode_g4 == 5 && dsp_g4 == false) {
		mode_g4 = 0;
		a4 = 0;
		midiOut.sendNoteOn(midiCh, CH_DMX_G4_DIM, 0);
	}


	// dsp mode
	int fff = ofGetFrameNum() % 2;
	if (mode_g1 == 5 && fff==0) {
		if (mB[cq_g1] > thr_g1) {
			a1 = ofMap(d0[cq_g1], thr_g1, top_g1, 0, 127, true);
		}
		else {
			a1 = 0;
		}
		//midiOut.sendNoteOn(midiCh, 4, 255);
		midiOut.sendNoteOn(midiCh, CH_DMX_G1_DIM, a1);
	}

	if (mode_g2 == 5 && fff == 0) {
		if (mB[cq_g2] > thr_g2) {
			a2 = ofMap(d0[cq_g2], thr_g2, top_g2, 0, 127, true);
		}
		else {
			a2 = 0;
		}
		midiOut.sendNoteOn(midiCh, CH_DMX_G2_DIM, a2);
	}

	if (mode_g3 == 5 && fff == 0) {
		if (mB[cq_g3] > thr_g3) {
			a3 = ofMap(d0[cq_g3], thr_g3, top_g3, 0, 127, true);
		}
		else {
			a3 = 0;
		}
		midiOut.sendNoteOn(midiCh, CH_DMX_G3_DIM, a3);
	}

	if (mode_g4 == 5 && fff == 0) {
		if (mB[cq_g4] > thr_g4) {
			a4 = ofMap(d0[cq_g4], thr_g4, top_g4, 0, 127, true);
		}
		else {
			a4 = 0;
		}
		midiOut.sendNoteOn(midiCh, CH_DMX_G4_DIM, a4);
	}


	/*
	*/
	canvas.begin();
	ofClear(0, 0);
	ofSetLineWidth(3);
	ofSetColor(225,245,255, 255);
	ofNoFill();
	ofDrawCircle(150, 100, mode_g1 == 1 ? 64 : a1 / 2);
	ofDrawCircle(150, 200, mode_g2 == 1 ? 64 : a2 / 2);
	ofDrawCircle(150, 300, mode_g3 == 1 ? 64 : a3 / 2);
	ofDrawCircle(150, 400, mode_g4 == 1 ? 64 : a4 / 2);

	canvas.end();
	//cout << "G1" << a1 << "  G2" << a2 << "  G3" << a3 << "  G4" << a4 << endl;
}



//--------------------------------------------------------------
void ofApp::draw(){
    
	// ---- ---- |DRAW THE GRAPHS| 
    float horizWidth = 500.;
    float horizOffset = 100;
    float fftTop = 250;
    float mfccTop = 350;
    float chromagramTop = 450;
	float chromabuffTop = 450;
    
    ofSetColor(255, 0, 0,255);    
    //FFT magnitudes:
    float xinc = horizWidth / fftSize * 2.0;
    for(int i=0; i < fftSize / 2; i++) {
        float height = mfft.magnitudes[i] * 100;
        ofRect(horizOffset + (i*xinc),250 - height,2, height);
    }
    myfont.drawString("FFT:", 30, 250);
    //MFCCs:
    ofSetColor(0, 0, 255, 200);
    xinc = horizWidth / 13;
    for(int i=0; i < 13; i++) {
        float height = mfccs[i] * 100.0;
        ofRect(horizOffset + (i*xinc),mfccTop - height,40, height);
    }
    myfont.drawString("MFCCs:", 12, mfccTop);
    //Const-Q:
	ofSetColor(255, 0, 255, 100);
	ofLine(horizOffset, chromagramTop - 50, horizOffset + horizWidth, chromagramTop - 50);
	ofLine(horizOffset, chromagramTop - 40, horizOffset + horizWidth, chromagramTop - 40);
	ofLine(horizOffset, chromagramTop - 30, horizOffset + horizWidth, chromagramTop - 30);
	ofLine(horizOffset, chromagramTop - 20, horizOffset + horizWidth, chromagramTop - 20);
	ofLine(horizOffset, chromagramTop - 10, horizOffset + horizWidth, chromagramTop - 10);
	//QBuff:
	ofSetColor(0, 255, 0, 100);
    xinc = horizWidth / oct.nAverages;
    for(int i=0; i < oct.nAverages; i++) {
		ofSetColor(255 - int(255 / nAverages), int(255 / nAverages)*int(i / 8), 0);
		float height = (oct.averages[i] * 5 );
		//float height = (mB[i] * 5);
		ofRect(horizOffset + (i*xinc),chromagramTop - height,2, height);
		if (i % 8 == 0) {
			myFont5.drawString(ofToString(i), horizOffset + (i*xinc), chromagramTop+12);
		}
    }
	//QBuff:
	ofSetColor(0, 0, 255, 100);
	xinc = horizWidth / oct.nAverages;
	for (int i = 0; i < oct.nAverages; i++) {
		ofSetColor(int(255 / nAverages)*int(i / 8), 255 - int(255 / nAverages), 0);
		//float height = (oct.averages[i] * 5 );
		float height = (mB[i] * 5);
		ofRect(horizOffset + (i*xinc), chromabuffTop - height, 2, height);
		if (i % 8 == 0) {
			myFont5.drawString(ofToString(i), horizOffset + (i*xinc), chromabuffTop + 12);
		}
	}
    myfont.drawString("ConstQ:", 12, chromagramTop-60);
	ofSetColor(255, 0, 255, 200);
	myFont5.drawString("2._", horizOffset - 15, chromagramTop - 10);
	myFont5.drawString("4._", horizOffset - 15, chromagramTop - 20);
	myFont5.drawString("6._", horizOffset - 15, chromagramTop - 30);
	myFont5.drawString("8._", horizOffset - 15, chromagramTop - 40);
	myFont5.drawString("10._", horizOffset - 15, chromagramTop - 50);
	ofSetLineWidth(1);

    ofSetColor(255, 255, 255,255);    
    char peakString[255]; // an array of chars
    sprintf(peakString, "Peak Frequency: %.2f", peakFreq);
    myfont.drawString(peakString, 100, 40);
    char centroidString[255]; // an array of chars
    sprintf(centroidString, "Spectral Centroid: %f", centroid);
    myfont.drawString(centroidString, 100, 70); 
    char rmsString[255]; // an array of chars
    sprintf(rmsString, "RMS: %.2f", RMS);
    myfont.drawString(rmsString, 100, 100); 

	/*
	int numInputs = 0;
    if (fftToggle) {
        numInputs += fftSize/2;
    }
    if (mfccToggle) {
        numInputs += 13;
    }
    if (chromagramToggle) {
        numInputs += 104;
    }
    if (peakFrequencyToggle) {
        numInputs++;
    }
    if (centroidToggle) {
        numInputs++;
    }
    if (rmsToggle) {
        numInputs++;
    }   
    char numInputsString[255]; // an array of chars
    //sprintf(numInputsString, "Sending %d inputs total", numInputs);
    myfont.drawString(numInputsString, 500, 40);*/

	
	ofSetColor(255, 255);
	canvas.draw(800, 20);


    if( bHide ){
        gui.draw();
    }
    
}


//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){
    
}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){
    
    
    
}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){
    
}


//--------------------------------------------------------------
void ofApp::audioRequested(float * output, int bufferSize, int nChannels) {
	for (int i = 0; i < bufferSize; i++) {
		wave = lAudioIn[i];
		if (mfft.process(wave)) {
			mfft.magsToDB();
			oct.calculate(mfft.magnitudesDB);
			float sum = 0;
			float maxFreq = 0;
			int maxBin = 0;
			for (int i = 0; i < fftSize / 2; i++) {
				sum += mfft.magnitudes[i];
				if (mfft.magnitudes[i] > maxFreq) {
					maxFreq = mfft.magnitudes[i];
					maxBin = i;
				}
			}
			centroid = sum / (fftSize / 2);
			peakFreq = (float)maxBin / fftSize * 44100;

			mfcc.mfcc(mfft.magnitudes, mfccs);
		}
		lAudioOut[i] = 0;
		rAudioOut[i] = 0;
	}
}


//--------------------------------------------------------------
void ofApp::audioReceived(float * input, int bufferSize, int nChannels) {
	/* You can just grab this input and stick it in a double, then use it above to create output*/
	float sum = 0;
	for (int i = 0; i < bufferSize; i++) {
		/* you can also grab the data out of the arrays*/
		lAudioIn[i] = input[i * 2];
		rAudioIn[i] = input[i * 2 + 1];

		sum += input[i * 2] * input[i * 2];
	}
	RMS = sqrt(sum);
}


//--------------------------------------------------------------
void ofApp::exit() {
	// clean up
	midiOut.closePort();
}